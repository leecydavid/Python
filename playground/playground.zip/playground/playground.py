from flask import Flask, render_template 
# render_template = need in order to connect template folder 
app = Flask(__name__)    

@app.route('/')          
def index():
    return "Hello! Please go to localhost5002 to play game!"


@app.route('/play')
def render_block():
    return render_template("index.html", num=3)

@app.route('/play/<int:num>')
def mult_block(num):
    return render_template("index.html", num=num)

@app.route('/play/<int:num>/<color>')
def change_color(num, color):
    return render_template("index.html", num=num, color=color)
if __name__=="__main__":       
    app.run(debug=True, port=5002)    
